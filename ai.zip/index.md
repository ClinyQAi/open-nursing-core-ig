# Home - Open Nursing Core FHIR Implementation Guide (ONC-IG) v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://opennursingcoreig.com/ImplementationGuide/onc.ig | *Version*:0.1.0 |
| Draft as of 2026-01-02 | *Computable Name*:OpenNursingCoreIG |

# Open Nursing Core FHIR Implementation Guide

Welcome to the **Open Nursing Core FHIR Implementation Guide (ONC-IG)**.

This IG provides **Standardized Nursing Data Models** for the NHS and beyond, focusing on the complete nursing process (ADPIE) and specialized care needs.

## 🌟 Core Philosophy

* **Holistic**: Covers physical, mental, and social needs.
* **Relational**: Captures "What Matters to Me" and patient stories.
* **Equitable**: Includes Safe Skin Tone (Monk Scale) and Reasonable Adjustments.

-------

## 📚 Profile Library

### 1. Foundation & Safety 🛡️

Base profiles for standard nursing operations.

* [OncNursingAssessment](StructureDefinition-onc-nursing-assessment.md)
* [OncNursingProblem](StructureDefinition-onc-nursing-problem.md) (Diagnosis)
* [OncPatientGoal](StructureDefinition-onc-patient-goal.md)
* [OncNursingIntervention](StructureDefinition-onc-nursing-intervention.md)
* [Braden Scale](StructureDefinition-onc-braden-scale-assessment.md) (Pressure Ulcer Risk)
* [Waterlow Score](StructureDefinition-onc-waterlow-score.md)
* [NEWS2](StructureDefinition-onc-news2-score.md) (Deterioration)

### 2. Relational & Inclusive Care ❤️

Capturing the person behind the patient.

* [What Matters To Me](StructureDefinition-onc-what-matters.md)
* [Patient Story](StructureDefinition-onc-patient-story.md)
* [Reasonable Adjustment](StructureDefinition-onc-reasonable-adjustment.md) (Equality Act)
* [Mental Capacity Assessment](StructureDefinition-onc-mental-capacity.md)
* [Skin Tone Observation](StructureDefinition-onc-skintone-observation.md) (Monk/Fitzpatrick)

### 3. Fundamental Care 💧

The essentials of daily nursing care.

* [Bristol Stool Chart](StructureDefinition-onc-bristol-stool-chart.md) (Elimination)
* [Fluid Balance](StructureDefinition-onc-fluid-balance.md) (Hydration)
* [Abbey Pain Scale](StructureDefinition-onc-abbey-pain-scale.md) (Non-verbal pain)
* [Oral Health](StructureDefinition-onc-oral-health.md)
* [Sleep Pattern](StructureDefinition-onc-sleep-pattern.md)

### 4. Specialized & Mental Health 🧠

Tools for Learning Disabilities, Mental Health, and Geriatrics.

* [ABC Chart](StructureDefinition-onc-abc-chart.md) (Positive Behaviour Support)
* [Seizure Record](StructureDefinition-onc-seizure-record.md) (Epilepsy)
* [Clinical Frailty Scale](StructureDefinition-onc-clinical-frailty-scale.md)
* [4AT Delirium Screen](StructureDefinition-onc-4at-delirium.md)
* [Urinalysis](StructureDefinition-onc-urinalysis.md)

-------

## 🚀 Getting Started

1. **Browse Artifacts**: See the[Artifacts Page](artifacts.md)for all JSON definitions.
1. **Download Package**:`npm install @clinyqai/open-nursing-core-ig`
1. **Contribute**: Visit[GitHub](https://github.com/ClinyQAi/open-nursing-core-ig).

-------

**Built with ❤️ by the Open Nursing Community**

