# Home - Open Nursing Core FHIR Implementation Guide (ONC-IG) v1.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://clinyqai.github.io/open-nursing-core-ig/ImplementationGuide/onc.ig | *Version*:1.0.0 |
| Active as of 2025-12-25 | *Computable Name*:OpenNursingCoreIG |

# Open Nursing Core FHIR Implementation Guide

Welcome to the **Open Nursing Core FHIR Implementation Guide (ONC-IG)**.

This Implementation Guide provides foundational FHIR R4 profiles for documenting the nursing process (ADPIE - Assessment, Diagnosis, Planning, Implementation, Evaluation), with a focus on **Safety** and **Equity** in nursing care.

## Overview

The ONC-IG defines standardized FHIR profiles for:

* **Patient Assessment** - Nursing observations and assessments
* **Nursing Diagnosis** - Problem identification and categorization
* **Patient Goals** - Goal setting and outcome evaluation
* **Nursing Interventions** - Care activities and procedures
* **Safety Assessments** - Braden Scale for pressure ulcer risk
* **Equity Considerations** - Skin tone documentation for equitable care

## Key Profiles

| | |
| :--- | :--- |
| [ONC Nursing Assessment](StructureDefinition-onc-nursing-assessment.md) | Base profile for all nursing observations |
| [Braden Scale Assessment](StructureDefinition-onc-braden-scale-assessment.md) | Pressure ulcer risk assessment |
| [Nursing Problem](StructureDefinition-onc-nursing-problem.md) | Nursing diagnosis documentation |
| [Patient Goal](StructureDefinition-onc-patient-goal.md) | Patient-centered goal setting |
| [Nursing Intervention](StructureDefinition-onc-nursing-intervention.md) | Care activity documentation |
| [Goal Evaluation](StructureDefinition-onc-goal-evaluation.md) | Outcome assessment |
| [Skin Tone Observation](StructureDefinition-onc-skintone-observation.md) | Fitzpatrick skin type for equitable assessment |

## Getting Started

* Browse the [Artifacts](artifacts.md) for all profiles, extensions, and examples
* Download the [full package](package.tgz) for use in your FHIR server

## License

This Implementation Guide is released under the MIT License.

## Contact

For questions or contributions, visit our [GitHub repository](https://github.com/ClinyQAi/open-nursing-core-ig).

